-- Sample (made-up) records from the Activity 6 CampusPulse project.
-- Inserts them ONLY when the table is empty, so running it twice cannot create duplicates.
INSERT INTO records (title, category, description, status)
SELECT v.title, v.category, v.description, v.status
FROM (VALUES
  ('Inter-faculty Quiz Night', 'Academic', 'A team quiz covering science, technology and general knowledge for all faculties.', 'Pending'),
  ('Campus 5K Fun Run', 'Sport', 'Morning charity run around the campus ring road, open to students and staff.', 'In progress'),
  ('Cultural Heritage Day', 'Culture', 'Students showcase traditional dance, music, food and dress from their home regions.', 'Completed'),
  ('Coding Hackathon Weekend', 'Technology', 'A 24-hour hackathon where teams build small web tools for campus problems.', 'Pending'),
  ('Inter-hostel Football Cup', 'Sport', 'Knockout football tournament between hostels with a trophy for the winning team.', 'In progress'),
  ('Poetry and Open Mic Evening', 'Culture', 'An evening of poetry, storytelling and live acoustic music in the main hall.', 'Completed'),
  ('Career Skills Workshop', 'Academic', 'Practical session on CV writing, interview practice and professional networking.', 'Pending'),
  ('Green Campus Tree Planting', 'Community', 'Volunteers plant trees near the library and sports field to mark environment week.', 'In progress'),
  ('Debate Club Challenge', 'Academic', 'Public debate competition on technology and society between student teams.', 'Pending')
) AS v(title, category, description, status)
WHERE NOT EXISTS (SELECT 1 FROM records);
