// Pure validation helpers (no database, no Express) so they are easy to unit-test.
const STATUSES = ["Pending", "In progress", "Completed"];
const MAX_ID = 2147483647; // largest value of a PostgreSQL INTEGER

const RULES = [
  { field: "title", label: "Title", min: 3, max: 80 },
  { field: "category", label: "Category", min: 2, max: 40 },
  { field: "description", label: "Description", min: 5, max: 300 }
];

// Returns the id as a number, or null when it is not a positive whole number.
function parseId(value) {
  if (typeof value !== "string" || !/^[1-9][0-9]*$/.test(value)) return null;
  const id = Number(value);
  return id <= MAX_ID ? id : null;
}

// Checks a POST/PUT body. Returns { clean, errors } where errors is a list of messages.
// Any "id" sent by the client is ignored on purpose.
function validateRecordBody(body) {
  if (body === null || typeof body !== "object" || Array.isArray(body)) {
    return { clean: null, errors: ["Request body must be a JSON object."] };
  }

  const clean = {};
  const errors = [];

  for (const { field, label, min, max } of RULES) {
    const value = body[field];
    if (value === undefined || value === null) {
      errors.push(`${label} is required.`);
    } else if (typeof value !== "string") {
      errors.push(`${label} must be a string.`);
    } else {
      const text = value.trim();
      if (text.length < min || text.length > max) {
        errors.push(`${label} must have ${min} to ${max} characters.`);
      } else {
        clean[field] = text;
      }
    }
  }

  const status = body.status;
  if (status === undefined || status === null) {
    errors.push("Status is required.");
  } else if (typeof status !== "string") {
    errors.push("Status must be a string.");
  } else if (!STATUSES.includes(status)) {
    errors.push("Status must be exactly Pending, In progress or Completed.");
  } else {
    clean.status = status;
  }

  return { clean: errors.length ? null : clean, errors };
}

module.exports = { STATUSES, parseId, validateRecordBody };
