// Creates and exports ONE shared PostgreSQL connection pool.
require("dotenv").config();
const { Pool } = require("pg");

const connectionString = process.env.DATABASE_URL;

function useSsl() {
  const flag = (process.env.DATABASE_SSL || "").trim().toLowerCase();
  if (flag === "true") return true;
  if (flag === "false") return false;
  // Not set: switch SSL on for Render-hosted databases.
  return /render\.com/i.test(connectionString || "");
}

if (!connectionString) {
  console.warn("Warning: DATABASE_URL is not set. Copy .env.example to .env and fill it in.");
}

const pool = new Pool({
  connectionString,
  ssl: useSsl() ? { rejectUnauthorized: false } : false,
  max: 10,
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 30000
});

// An idle client can lose its connection; log it without crashing the server.
pool.on("error", (error) => {
  console.error("Unexpected database pool error:", error.message);
});

module.exports = pool;
