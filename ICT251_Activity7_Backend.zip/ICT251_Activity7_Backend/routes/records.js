// The five record routes. All SQL uses $1, $2 ... placeholders (never string concatenation).
const router = require("express").Router();
const pool = require("../db");
const { parseId, validateRecordBody } = require("../validation");

const COLUMNS = "id, title, category, description, status";

function badRequest(res, message, errors) {
  const body = { message };
  if (errors && errors.length > 1) body.errors = errors;
  return res.status(400).json(body);
}

// GET /api/records - all records ordered by id ([] when empty)
router.get("/", async (req, res, next) => {
  try {
    const result = await pool.query(`SELECT ${COLUMNS} FROM records ORDER BY id`);
    res.status(200).json(result.rows);
  } catch (error) {
    next(error);
  }
});

// GET /api/records/:id - one record
router.get("/:id", async (req, res, next) => {
  try {
    const id = parseId(req.params.id);
    if (id === null) return badRequest(res, "ID must be a positive whole number.");

    const result = await pool.query(`SELECT ${COLUMNS} FROM records WHERE id = $1`, [id]);
    if (result.rows.length === 0) return res.status(404).json({ message: "Record not found." });
    res.status(200).json(result.rows[0]);
  } catch (error) {
    next(error);
  }
});

// POST /api/records - create (the database generates the id)
router.post("/", async (req, res, next) => {
  try {
    const { clean, errors } = validateRecordBody(req.body);
    if (errors.length) return badRequest(res, errors[0], errors);

    const result = await pool.query(
      `INSERT INTO records (title, category, description, status)
       VALUES ($1, $2, $3, $4) RETURNING ${COLUMNS}`,
      [clean.title, clean.category, clean.description, clean.status]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    next(error);
  }
});

// PUT /api/records/:id - replace all four editable fields (never creates a record)
router.put("/:id", async (req, res, next) => {
  try {
    const id = parseId(req.params.id);
    if (id === null) return badRequest(res, "ID must be a positive whole number.");

    const { clean, errors } = validateRecordBody(req.body);
    if (errors.length) return badRequest(res, errors[0], errors);

    const result = await pool.query(
      `UPDATE records SET title = $1, category = $2, description = $3, status = $4
       WHERE id = $5 RETURNING ${COLUMNS}`,
      [clean.title, clean.category, clean.description, clean.status, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ message: "Record not found." });
    res.status(200).json(result.rows[0]);
  } catch (error) {
    next(error);
  }
});

// DELETE /api/records/:id - remove a record
router.delete("/:id", async (req, res, next) => {
  try {
    const id = parseId(req.params.id);
    if (id === null) return badRequest(res, "ID must be a positive whole number.");

    const result = await pool.query("DELETE FROM records WHERE id = $1 RETURNING id", [id]);
    if (result.rows.length === 0) return res.status(404).json({ message: "Record not found." });
    res.status(200).json({ message: "Record deleted." });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
