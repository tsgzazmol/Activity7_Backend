-- ICT251 Activity 7 - CampusPulse (Student Event Proposals)
-- Safe to run more than once: nothing is dropped or duplicated.
CREATE TABLE IF NOT EXISTS records (
  id          INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  title       VARCHAR(80)  NOT NULL CHECK (char_length(btrim(title)) BETWEEN 3 AND 80),
  category    VARCHAR(40)  NOT NULL CHECK (char_length(btrim(category)) BETWEEN 2 AND 40),
  description VARCHAR(300) NOT NULL CHECK (char_length(btrim(description)) BETWEEN 5 AND 300),
  status      VARCHAR(20)  NOT NULL CHECK (status IN ('Pending', 'In progress', 'Completed')),
  CONSTRAINT records_id_positive CHECK (id > 0)
);
