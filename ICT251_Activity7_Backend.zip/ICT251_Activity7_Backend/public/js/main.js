// Small helpers for the API guide page. The API itself does not need this file.
(function () {
  const origin = window.location.origin;
  const baseEl = document.getElementById("base-url");
  baseEl.textContent = origin;

  document.getElementById("copy-base").addEventListener("click", function (event) {
    const button = event.currentTarget;
    const done = () => { button.textContent = "Copied"; setTimeout(() => (button.textContent = "Copy"), 1500); };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(origin).then(done, () => window.prompt("Copy this address:", origin));
    } else {
      window.prompt("Copy this address:", origin);
    }
  });

  const hostNote = document.getElementById("host-note");
  if (/\.onrender\.com$/i.test(window.location.hostname)) {
    hostNote.textContent = "Hosting status: this page is being served from a Render address (" + window.location.hostname + ").";
  } else if (/^(localhost|127\.0\.0\.1)$/.test(window.location.hostname)) {
    hostNote.textContent = "Hosting status: running locally on your computer (not the hosted version).";
  }

  const button = document.getElementById("health-btn");
  const box = document.getElementById("health-result");
  button.addEventListener("click", async function () {
    button.disabled = true;
    button.textContent = "Checking...";
    box.hidden = false;
    box.className = "result";
    box.textContent = "Contacting the server. A sleeping hosted service may take a minute.";
    try {
      const response = await fetch("/health");
      const data = await response.json();
      box.className = "result " + (response.ok ? "ok" : "err");
      box.innerHTML = "";
      const title = document.createElement("strong");
      title.textContent = response.ok ? "Server and database are working (HTTP " + response.status + ")" : "Problem found (HTTP " + response.status + ")";
      const body = document.createElement("pre");
      body.textContent = JSON.stringify(data, null, 2);
      box.append(title, body);
    } catch (error) {
      box.className = "result err";
      box.textContent = "Could not reach the server. Check that it is running, then try again.";
    } finally {
      button.disabled = false;
      button.textContent = "Check server health";
    }
  });
})();
