# CampusPulse API - ICT251 Activity 7 (Backend Development)

| | |
|---|---|
| Student | Patrick Mposama (202505519) |
| Course | ICT251 - Introduction to Web Technologies |
| University | Mulungushi University, School of Engineering and Technology, Computer Science Department |
| Due | 24 November 2026, 23:59hrs |

## 1. Overview

This is the backend for **CampusPulse - Student Event Proposals**, the system chosen in Activity 6. It is an independent REST API built with Node.js, Express and PostgreSQL. It does not need the frontend: Postman, a browser address bar or any other HTTP client can use it.

Each record is an event proposal with the same field names as Activity 6: `id`, `title`, `category`, `description`, `status`.

**Objectives:** provide GET, POST, PUT and DELETE routes; validate every request on the server; store data permanently in PostgreSQL; return correct status codes and JSON errors; show an API guide at `GET /`; host the service on Render.

## 2. Technologies

Node.js (active LTS), npm, Express, `pg` (PostgreSQL driver), `dotenv`, `cors`, PostgreSQL, HTML5/CSS3/JavaScript (API guide page), Git/GitHub, Render. CommonJS (`require`) is used; `package.json` has no `"type": "module"`.

## 3. Project structure

```
ICT251_Activity7_Backend/
  server.js              Express app, middleware, GET /, GET /health, error handlers
  db.js                  PostgreSQL connection pool
  validation.js          Validation rules (id, title, category, description, status)
  routes/records.js      The five /api/records routes
  schema.sql             Creates the records table
  seed.sql               Inserts 9 sample records, only when the table is empty
  scripts/setup-database.js   Runs schema.sql and seed.sql  (npm run setup)
  public/                API guide page (index.html, css/style.css, js/main.js)
  tests/validation.test.js    Unit tests (npm test)
  tests/api-tests.js          Tests against a running server (npm run test:api)
  docs/API_DOCUMENTATION.md   Full API reference
  docs/TESTING.md             Test plan and result sheet
  windows/INSTALL.bat START.bat TEST.bat
  .github/workflows/node.js.yml   Runs unit tests on GitHub
  .env.example  .gitignore  package.json
```

## 4. Windows 11 setup (nothing is assumed to be installed)

### 4.1 Install the tools
1. **Node.js LTS**: download from https://nodejs.org and install with the default options. Check in a new Command Prompt: `node -v` and `npm -v`.
2. **PostgreSQL** (for running locally): download from https://www.postgresql.org/download/windows/ . During setup, choose a password for the `postgres` user and **write it down**. Keep port `5432`.
   *No local PostgreSQL?* You can use a Render PostgreSQL database instead (section 8) and paste its **External Database URL** into `.env`.
3. **Git** (for GitHub): https://git-scm.com/download/win
4. **VS Code** (optional): https://code.visualstudio.com

### 4.2 Create the local database
Open **SQL Shell (psql)** from the Start menu, press Enter for the defaults, enter your password, then run:

```sql
CREATE DATABASE campuspulse;
```

### 4.3 Install and configure
1. Extract the ZIP. Open the `ICT251_Activity7_Backend` folder.
2. Open the `windows` folder and double-click **INSTALL.bat**. It checks Node and npm, runs `npm install`, and creates `.env` from `.env.example`.
3. Open `.env` in Notepad and replace `YOUR_PASSWORD` in `DATABASE_URL` with your PostgreSQL password. If the password has symbols such as `@` or `#`, URL-encode them (`@` becomes `%40`).
4. Double-click **START.bat**. The window must say `Server listening on port 3000` and `Database ready.` Keep it open.
5. Open http://localhost:3000 for the API guide, or http://localhost:3000/api/records for the data.
6. Double-click **TEST.bat** (while the server is running in another window) to run the automated tests.

### 4.4 Run with VS Code
File > Open Folder > `ICT251_Activity7_Backend`. Open the terminal (Ctrl+`) and run `npm install`, then `npm start`. Stop with Ctrl+C.

### 4.5 PowerShell says "npm.ps1 cannot be loaded"
Windows can block `npm.ps1`. Use `npm.cmd` instead, for example `npm.cmd install` and `npm.cmd start`. The `.bat` files already do this. Alternatively use Command Prompt.

## 5. Database

- Table `records` (see `schema.sql`): `id` auto-generated identity (starts at 1), `title` 3-80, `category` 2-40, `description` 5-300, `status` one of `Pending`, `In progress`, `Completed`. CHECK constraints repeat these rules inside the database.
- `seed.sql` holds the 9 made-up records from Activity 6. It inserts them **only when the table is empty**, so running it again never duplicates them.
- The server creates the table on start-up (`CREATE TABLE IF NOT EXISTS`) and inserts the samples when `AUTO_SEED=true`. You can also run `npm run setup` yourself.
- Records live in PostgreSQL, so they survive server restarts.

Environment variables (`.env`, never committed):

| Name | Purpose |
|---|---|
| `PORT` | Local port (default 3000; Render sets its own) |
| `DATABASE_URL` | PostgreSQL connection string |
| `DATABASE_SSL` | `true` for Render's External URL, `false` locally. If unset, SSL turns on automatically for `render.com` hosts |
| `CLIENT_ORIGINS` | Comma-separated browser origins allowed by CORS (for Activity 8) |
| `AUTO_SEED` | `true` inserts sample records on start-up if the table is empty |

## 6. API endpoints

| Method | Route | Purpose | Success |
|---|---|---|---|
| GET | `/` | API guide page | 200 |
| GET | `/health` | Server + database check | 200 / 503 |
| GET | `/api/records` | All records (`[]` if none) | 200 |
| GET | `/api/records/:id` | One record | 200 |
| POST | `/api/records` | Create a record | 201 |
| PUT | `/api/records/:id` | Replace the four editable fields | 200 |
| DELETE | `/api/records/:id` | Delete a record | 200 `{"message":"Record deleted."}` |

Request body for POST and PUT (do not send `id`; if you do, it is ignored):

```json
{
  "title": "Broken classroom light",
  "category": "Electrical",
  "description": "The light in Room B12 does not switch on.",
  "status": "Pending"
}
```

See `docs/API_DOCUMENTATION.md` for every response.

## 7. Validation rules and error codes

- `id` in the URL: positive whole number (1 to 2147483647).
- `title`, `category`, `description`, `status` must all be present and be **strings**. Text is trimmed, then checked: title 3-80, category 2-40, description 5-300 characters.
- `status` must be exactly `Pending`, `In progress` or `Completed` (case-sensitive, not trimmed).
- Rejected: missing values, empty or spaces-only strings, wrong types, wrong lengths, unknown status, invalid ids, malformed JSON.

| Code | Meaning |
|---|---|
| 200 | GET, PUT or DELETE succeeded |
| 201 | Record created |
| 400 | Invalid input, invalid id or malformed JSON |
| 404 | Valid id that does not exist, or unknown route |
| 500 | Unexpected server error (details only in the server log) |
| 503 | `/health` cannot reach the database |

Every error is JSON with a `message`, for example `{"message":"Title must have 3 to 80 characters."}`. When several fields are wrong, an `errors` list is added too; `message` shows the first problem.

## 8. Testing

**Automated**
- `npm test` - 11 unit tests of the validation rules (need only Node).
- `npm run test:api` - sends real requests to a running server (default `http://localhost:3000`; use `BASE_URL=https://your-service.onrender.com` for the hosted API) and writes the real outcome to `docs/TEST_RESULTS.md`.

**Postman** (the 17 required tests are listed in `docs/TESTING.md` with a result sheet). For POST and PUT choose Body > raw > JSON.

**Test 16 - database failure:** stop PostgreSQL (Services app, or set a wrong password in `.env`), restart the server, open `/health`. Expect `503` and JSON with a message; the server itself keeps running.

**Test 17 - persistence:** POST a record, note its id, stop the server (Ctrl+C), start it again, then `GET /api/records/<id>`. The record must still be there.

## 9. GitHub

1. Run `npm install` once so `package-lock.json` exists. Commit **both** `package.json` and `package-lock.json`.
2. Create a new empty repository on https://github.com (no README).
3. In the project folder:
```
git init
git add .
git commit -m "ICT251 Activity 7 backend"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO.git
git push -u origin main
```
4. Check on GitHub that `.env` and `node_modules` are **not** listed. `.gitignore` already excludes them.

## 10. Deploy on Render

Plans and limits change, so check Render's pages when you sign up. When this guide was prepared, Render's documentation said Free web services sleep when idle and have a temporary filesystem, and that a Free Render Postgres database has a 1 GB limit and **expires 30 days after creation** (https://render.com/docs/free). Create your database close to the marking date and note its expiry.

1. Sign in at https://render.com (GitHub login is easiest).
2. **Database:** New > **Postgres**. Choose a name (e.g. `campuspulse-db`), a region, and the Free plan. Create it. When it is ready, open it and copy the **Internal Database URL**.
3. **Web service:** New > **Web Service** > connect your GitHub repository. If the project is inside another folder, set **Root Directory** to that folder.
4. Settings: Language/Runtime **Node**; **Build Command** `npm install`; **Start Command** `npm start`; instance type **Free**.
5. **Environment variables:**
   - `DATABASE_URL` = the Internal Database URL
   - `DATABASE_SSL` = `false` (Internal URL) - or `true` if you used the External URL
   - `CLIENT_ORIGINS` = your frontend address(es), comma-separated (e.g. `https://your-site.netlify.app`). Add localhost entries only if you need them.
   - `AUTO_SEED` = `true`
6. Click **Create Web Service**. Open the **Logs** tab and wait for `Server listening on port ...` and `Database ready.`
7. Open the service URL (ends in `.onrender.com`). You should see the API guide. Then open `/health` and `/api/records`.
8. Repeat the CRUD tests on the hosted API: `BASE_URL=https://your-service.onrender.com npm run test:api`, or use Postman.
9. Submit the base URL (no trailing path), e.g. `https://your-backend.onrender.com`.

The app listens on `process.env.PORT || 3000` and binds to `0.0.0.0`, as Render requires. Never paste your database URL into code or commit `.env`.

## 11. Troubleshooting

| Problem | Fix |
|---|---|
| `node` is not recognized | Install Node.js LTS, then open a **new** terminal |
| `npm.ps1 cannot be loaded` | Use `npm.cmd` or Command Prompt |
| `password authentication failed` | Wrong password in `DATABASE_URL`; URL-encode special characters |
| `database "campuspulse" does not exist` | Run `CREATE DATABASE campuspulse;` in psql |
| `ECONNREFUSED 127.0.0.1:5432` | PostgreSQL is not running; start the service |
| `/health` returns 503 | The database is unreachable; check `DATABASE_URL`, SSL setting and logs |
| `EADDRINUSE` (port in use) | Close the other server window or change `PORT` |
| Render deploy fails at `npm ci` or lock-file errors | Commit `package-lock.json` created by `npm install` |
| Hosted first request is slow | Free services sleep when idle; wait about a minute and retry |
| Browser blocks a call from your frontend | Add the frontend's exact origin to `CLIENT_ORIGINS` |
