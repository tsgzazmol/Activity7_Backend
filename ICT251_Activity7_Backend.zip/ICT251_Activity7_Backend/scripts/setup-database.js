// Creates the records table and (optionally) inserts the sample records.
// Run manually with:  npm run setup      Also called by server.js on start-up.
const fs = require("fs");
const path = require("path");
const pool = require("../db");

const root = path.join(__dirname, "..");
const readSql = (name) => fs.readFileSync(path.join(root, name), "utf8");

async function runSetup({ seed = true } = {}) {
  await pool.query(readSql("schema.sql"));
  if (seed) await pool.query(readSql("seed.sql")); // only inserts when the table is empty
}

module.exports = { runSetup };

if (require.main === module) {
  runSetup({ seed: true })
    .then(async () => {
      const { rows } = await pool.query("SELECT COUNT(*)::int AS total FROM records");
      console.log(`Database ready. The records table now holds ${rows[0].total} record(s).`);
    })
    .catch((error) => {
      console.error("Database setup failed:", error.message);
      process.exitCode = 1;
    })
    .finally(() => pool.end());
}
