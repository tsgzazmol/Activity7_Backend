// ICT251 Activity 7 - CampusPulse backend (Express + PostgreSQL)
require("dotenv").config();
const path = require("path");
const express = require("express");
const cors = require("cors");
const pool = require("./db");
const { runSetup } = require("./scripts/setup-database");

const app = express();

const origins = (process.env.CLIENT_ORIGINS || "")
  .split(",").map((value) => value.trim()).filter(Boolean);

app.disable("x-powered-by");
app.use(cors({ origin: origins }));
app.use(express.json({ limit: "10kb" }));

// GET / - the API guide for the marker
const publicDir = path.join(__dirname, "public");
app.get("/", (req, res) => res.sendFile(path.join(publicDir, "index.html")));
app.use(express.static(publicDir, { index: false }));

// GET /health - server and database check
app.get("/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.status(200).json({
      status: "ok",
      server: "running",
      database: "connected",
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error("Health check failed:", error.message);
    res.status(503).json({
      status: "error",
      server: "running",
      database: "unavailable",
      message: "The server is running but the database is unavailable."
    });
  }
});

app.use("/api/records", require("./routes/records"));

// Unknown routes -> JSON 404
app.use((req, res) => {
  res.status(404).json({ message: "Route not found." });
});

// Central error handler (4 parameters). Details are logged, never sent to the client.
// eslint-disable-next-line no-unused-vars
app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);

  if (error.type === "entity.parse.failed") {
    return res.status(400).json({ message: "Malformed JSON. Send a valid JSON body." });
  }
  if (error.type === "entity.too.large") {
    return res.status(400).json({ message: "Request body is too large." });
  }
  if (error.status >= 400 && error.status < 500) {
    return res.status(400).json({ message: "The request could not be read. Check the body and headers." });
  }

  console.error("Unexpected error:", error.stack || error.message);
  res.status(500).json({ message: "Unexpected server error. Please try again later." });
});

module.exports = app;

if (require.main === module) {
  const port = process.env.PORT || 3000;
  const server = app.listen(port, "0.0.0.0", () => {
    console.log(`Server listening on port ${port}`);
    console.log(`Local address: http://localhost:${port}`);
  });

  // Prepare the table on start-up. If the database is down the server stays up,
  // and /health reports 503 until the database comes back.
  runSetup({ seed: (process.env.AUTO_SEED || "").trim().toLowerCase() === "true" })
    .then(() => console.log("Database ready."))
    .catch((error) => console.error("Database start-up check failed:", error.message));

  const shutdown = () => {
    server.close(() => pool.end().finally(() => process.exit(0)));
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}
