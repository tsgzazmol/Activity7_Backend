# Testing document - ICT251 Activity 7

Base URL used for each run: `http://localhost:3000` (local) and the hosted URL (online).
Fill the **Actual** and **Result** columns from your own Postman runs. A test is only PASS if you executed it and the status code and body match. `npm run test:api` runs tests 1-15 automatically and saves real output in `docs/TEST_RESULTS.md`.

Valid body used below (V): `{"title":"Broken classroom light","category":"Electrical","description":"The light in Room B12 does not switch on.","status":"Pending"}`

| # | Test | Method | URL | Body | Expected | Actual | Result |
|---|---|---|---|---|---|---|---|
| 1 | Health | GET | /health | - | 200, `database":"connected"` | | |
| 2 | All records | GET | /api/records | - | 200, JSON array | | |
| 3 | Create | POST | /api/records | V | 201, record with new id (note it) | | |
| 4 | Read one | GET | /api/records/{id} | - | 200, same record | | |
| 5 | Update | PUT | /api/records/{id} | V with changed values | 200, changed values, same id | | |
| 6 | Delete | DELETE | /api/records/{id} | - | 200, `{"message":"Record deleted."}`; then GET gives 404 | | |
| 7 | Missing title | POST | /api/records | V without title | 400, `Title is required.` | | |
| 8 | Invalid status | POST | /api/records | V with `"status":"Done"` | 400, status message | | |
| 9 | Wrong types | POST | /api/records | `{"title":123,"category":["x"],"description":true,"status":null}` | 400, message | | |
| 10 | Invalid id | GET | /api/records/abc | - | 400, message | | |
| 11 | Missing record | GET | /api/records/2000000000 | - | 404, `Record not found.` | | |
| 12 | PUT missing | PUT | /api/records/2000000000 | V | 404 | | |
| 13 | DELETE missing | DELETE | /api/records/2000000000 | - | 404 | | |
| 14 | Malformed JSON | POST | /api/records | `{"title": "x",` | 400, `Malformed JSON...` | | |
| 15 | Unknown route | GET | /api/unknown | - | 404, `Route not found.` | | |
| 16 | Database failure | GET | /health | stop PostgreSQL or use a wrong password, restart server | 503, JSON message | | |
| 17 | Persistence | GET | /api/records/{id} | create record, restart server, read it | 200, record still exists | | |

## What was actually verified while building this project

Verified in the build environment (which had Node.js but no PostgreSQL, no internet and no Express package):

- `npm test`: 11 of 11 validation unit tests passed.
- Route handler logic (`routes/records.js`) was run against an in-memory stand-in for the database: 17 of 17 checks passed (status codes, bodies, id handling, 404/400 rules, error forwarding on database failure).
- All JavaScript files passed `node --check` syntax checks.

NOT verified in the build environment (you must run these on your computer): the real Express server, real PostgreSQL SQL execution, the `/` guide page in a browser, `.bat` files on Windows, GitHub, and Render. Nothing here claims a live deployment.
