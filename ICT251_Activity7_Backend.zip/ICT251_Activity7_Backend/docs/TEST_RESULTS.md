# Automated API test results

Target: http://localhost:3000
Run at: 2026-11-20T21:13:11.062Z
Result: 8 of 20 passed

| Test | Method | URL | Request body | Actual response | Result |
|---|---|---|---|---|---|
| 1. GET /health | GET | /health | - | 503 {"status":"error","server":"running","database":"unavailable","message":"The server is running but the database is unavailable."} | FAIL |
| 2. GET all records | GET | /api/records | - | 500 {"message":"Unexpected server error. Please try again later."} | FAIL |
| 3. POST valid record | POST | /api/records | {"title":"Broken classroom light","category":"Electrical","description":"The light in Room B12 does not switch on.","status":"Pending"} | 500 {"message":"Unexpected server error. Please try again later."} | FAIL |
| 3b. POST ignores client-supplied id | POST | /api/records | {"title":"Broken classroom light","category":"Electrical","description":"The light in Room B12 does not switch on.","status":"Pending","id":99999} | 500 {"message":"Unexpected server error. Please try again later."} | FAIL |
| 4. GET one record | GET | /api/records/null | - | 400 {"message":"ID must be a positive whole number."} | FAIL |
| 5. PUT same id | PUT | /api/records/null | {"title":"Light repaired","category":"Facilities","description":"Electrician replaced the faulty bulb.","status":"Completed"} | 400 {"message":"ID must be a positive whole number."} | FAIL |
| 6. DELETE same id | DELETE | /api/records/null | - | 400 {"message":"ID must be a positive whole number."} | FAIL |
| 6b. GET deleted id gives 404 | GET | /api/records/null | - | 400 {"message":"ID must be a positive whole number."} | FAIL |
| 7. POST missing title | POST | /api/records | {"category":"Electrical","description":"The light does not work.","status":"Pending"} | 400 {"message":"Title is required."} | PASS |
| 8. POST invalid status | POST | /api/records | {"title":"Broken classroom light","category":"Electrical","description":"The light in Room B12 does not switch on.","status":"Done"} | 400 {"message":"Status must be exactly Pending, In progress or Completed."} | PASS |
| 9. POST wrong data types | POST | /api/records | {"title":123,"category":["x"],"description":true,"status":null} | 400 {"message":"Title must be a string.","errors":["Title must be a string.","Category must be a string.","Description must be a string.","Status is required."]} | PASS |
| 10. Invalid id (abc) | GET | /api/records/abc | - | 400 {"message":"ID must be a positive whole number."} | PASS |
| 10b. Invalid id (0) | DELETE | /api/records/0 | - | 400 {"message":"ID must be a positive whole number."} | PASS |
| 11. GET nonexistent id | GET | /api/records/2000000000 | - | 500 {"message":"Unexpected server error. Please try again later."} | FAIL |
| 12. PUT nonexistent id | PUT | /api/records/2000000000 | {"title":"Broken classroom light","category":"Electrical","description":"The light in Room B12 does not switch on.","status":"Pending"} | 500 {"message":"Unexpected server error. Please try again later."} | FAIL |
| 13. DELETE nonexistent id | DELETE | /api/records/2000000000 | - | 500 {"message":"Unexpected server error. Please try again later."} | FAIL |
| 14. Malformed JSON | POST | /api/records | {"title": "Broken light",  | 400 {"message":"Malformed JSON. Send a valid JSON body."} | PASS |
| 15. Unknown route | GET | /api/unknown | - | 404 {"message":"Route not found."} | PASS |
| 15b. GET / returns the HTML guide | GET | / | - | 200 <!DOCTYPE html> <html lang="en"> <head> <meta charset="UTF-8"> <meta name="viewport" content="width=device-width, initial-scale=1"> <title>CampusPulse API... | PASS |
| 2b. Final check: list is still a JSON array | GET | /api/records | - | 500 {"message":"Unexpected server error. Please try again later."} | FAIL |

Tests 16 (database connection failure) and 17 (persistence after restart) are manual; record them in docs/TESTING.md.
