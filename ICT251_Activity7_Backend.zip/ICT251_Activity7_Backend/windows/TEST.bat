@echo off
setlocal
title CampusPulse API - Tests
cd /d "%~dp0.."

if not exist "node_modules" (
  echo [ERROR] Packages are not installed yet. Run INSTALL.bat first.
  pause
  exit /b 1
)

echo ==========================================
echo  Step 1 of 2: Unit tests - validation rules
echo ==========================================
call npm.cmd test
set UNIT_RESULT=%ERRORLEVEL%

echo.
echo ==========================================
echo  Step 2 of 2: API tests - the server must be running
echo  Open another window and run START.bat first.
echo ==========================================
call npm.cmd run test:api
set API_RESULT=%ERRORLEVEL%

echo.
if "%UNIT_RESULT%"=="0" (echo Unit tests: PASSED) else (echo Unit tests: FAILED)
if "%API_RESULT%"=="0" (echo API tests: PASSED - see docs\TEST_RESULTS.md) else (echo API tests: FAILED or server not running)
pause
endlocal
