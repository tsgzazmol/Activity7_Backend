@echo off
setlocal
title CampusPulse API - Install
cd /d "%~dp0.."
echo ==========================================
echo  CampusPulse API - Install dependencies
echo ==========================================
echo Project folder: %CD%
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js was not found.
  echo Install the LTS version from https://nodejs.org , then close this window,
  echo open it again and re-run INSTALL.bat.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node -v') do set NODE_VERSION=%%v
echo Node.js found: %NODE_VERSION%

where npm.cmd >nul 2>nul
if errorlevel 1 (
  echo [ERROR] npm was not found. Re-install Node.js from https://nodejs.org
  pause
  exit /b 1
)
for /f "delims=" %%v in ('npm.cmd -v') do set NPM_VERSION=%%v
echo npm found: %NPM_VERSION%
echo.

echo Installing packages. This can take a minute...
call npm.cmd install
if errorlevel 1 (
  echo.
  echo [ERROR] npm install failed. Check your internet connection and read the messages above.
  pause
  exit /b 1
)

if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo.
  echo Created a new .env file from .env.example.
  echo IMPORTANT: open .env in Notepad or VS Code and put your real PostgreSQL password in DATABASE_URL.
)

echo.
echo Install finished. Next step: set DATABASE_URL in .env, then run START.bat
pause
endlocal
