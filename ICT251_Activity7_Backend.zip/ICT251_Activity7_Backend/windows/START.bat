@echo off
setlocal
title CampusPulse API - Server
cd /d "%~dp0.."

if not exist "node_modules" (
  echo [ERROR] Packages are not installed yet. Run INSTALL.bat first.
  pause
  exit /b 1
)
if not exist ".env" (
  echo [ERROR] The .env file is missing. Run INSTALL.bat, then edit .env.
  pause
  exit /b 1
)

echo ==========================================
echo  CampusPulse API
echo ==========================================
echo Starting the server. Keep this window open.
echo When it says "Server listening", open: http://localhost:3000
echo Press Ctrl+C to stop the server.
echo.
call npm.cmd start
echo.
echo The server has stopped. Read any error message above.
pause
endlocal
