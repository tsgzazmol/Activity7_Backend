// Unit tests for validation.js. They need only Node.js (no database, no server).
// Run with:  npm test
const test = require("node:test");
const assert = require("node:assert/strict");
const { parseId, validateRecordBody } = require("../validation");

const valid = {
  title: "Broken classroom light",
  category: "Electrical",
  description: "The light in Room B12 does not switch on.",
  status: "Pending"
};

test("parseId accepts positive whole numbers", () => {
  assert.equal(parseId("1"), 1);
  assert.equal(parseId("42"), 42);
  assert.equal(parseId("2147483647"), 2147483647);
});

test("parseId rejects everything else", () => {
  for (const bad of ["0", "-1", "abc", "1.5", "1e3", " 7", "7 ", "", "01", "2147483648", "99999999999999999999", undefined, null, 5]) {
    assert.equal(parseId(bad), null, `should reject ${JSON.stringify(bad)}`);
  }
});

test("a valid body passes and strings are trimmed", () => {
  const { clean, errors } = validateRecordBody({ ...valid, title: "  Broken classroom light  " });
  assert.deepEqual(errors, []);
  assert.deepEqual(clean, valid);
});

test("a client-supplied id is ignored", () => {
  const { clean, errors } = validateRecordBody({ ...valid, id: 999 });
  assert.deepEqual(errors, []);
  assert.equal("id" in clean, false);
});

test("missing fields are rejected", () => {
  for (const field of ["title", "category", "description", "status"]) {
    const body = { ...valid };
    delete body[field];
    const { errors } = validateRecordBody(body);
    assert.equal(errors.length, 1, field);
    assert.match(errors[0], /is required/);
  }
});

test("null, numbers, booleans, arrays and objects are rejected as wrong types", () => {
  for (const bad of [123, true, ["x"], { a: 1 }]) {
    for (const field of ["title", "category", "description", "status"]) {
      const { errors } = validateRecordBody({ ...valid, [field]: bad });
      assert.match(errors[0], /must be a string/, `${field}=${JSON.stringify(bad)}`);
    }
  }
  assert.match(validateRecordBody({ ...valid, title: null }).errors[0], /is required/);
});

test("empty and whitespace-only strings are rejected", () => {
  for (const bad of ["", "   ", "\t\n"]) {
    assert.equal(validateRecordBody({ ...valid, title: bad }).errors[0], "Title must have 3 to 80 characters.");
  }
});

test("length limits are enforced after trimming (boundaries)", () => {
  const ok = (field, n) => validateRecordBody({ ...valid, [field]: "a".repeat(n) }).errors.length === 0;
  assert.equal(ok("title", 2), false);  assert.equal(ok("title", 3), true);
  assert.equal(ok("title", 80), true);  assert.equal(ok("title", 81), false);
  assert.equal(ok("category", 1), false); assert.equal(ok("category", 2), true);
  assert.equal(ok("category", 40), true); assert.equal(ok("category", 41), false);
  assert.equal(ok("description", 4), false); assert.equal(ok("description", 5), true);
  assert.equal(ok("description", 300), true); assert.equal(ok("description", 301), false);
  assert.equal(validateRecordBody({ ...valid, title: "  ab  " }).errors[0], "Title must have 3 to 80 characters.");
});

test("status must match exactly", () => {
  for (const good of ["Pending", "In progress", "Completed"]) {
    assert.deepEqual(validateRecordBody({ ...valid, status: good }).errors, []);
  }
  for (const bad of ["pending", "In Progress", "Done", "", " Pending", "Completed "]) {
    assert.equal(validateRecordBody({ ...valid, status: bad }).errors[0], "Status must be exactly Pending, In progress or Completed.", JSON.stringify(bad));
  }
});

test("a body that is not an object is rejected", () => {
  for (const bad of [undefined, null, "text", 5, [], [valid]]) {
    assert.deepEqual(validateRecordBody(bad).errors, ["Request body must be a JSON object."]);
  }
});

test("all problems are reported, first one leads", () => {
  const { errors } = validateRecordBody({});
  assert.equal(errors.length, 4);
  assert.equal(errors[0], "Title is required.");
});
