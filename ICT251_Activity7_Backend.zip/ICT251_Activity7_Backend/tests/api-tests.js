// End-to-end API tests. They call a RUNNING server and check real status codes and bodies.
// 1. Start the server (START.bat or npm start)   2. Run:  npm run test:api
// Optional: BASE_URL=https://your-backend.onrender.com npm run test:api
// Writes the real results to docs/TEST_RESULTS.md. Needs Node 18+ (built-in fetch).
const fs = require("fs");
const path = require("path");

const BASE = (process.env.BASE_URL || "http://localhost:3000").replace(/\/+$/, "");
const valid = {
  title: "Broken classroom light",
  category: "Electrical",
  description: "The light in Room B12 does not switch on.",
  status: "Pending"
};
const results = [];
let createdId = null;

async function call(method, url, body, rawBody) {
  const options = { method, headers: {} };
  if (rawBody !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = rawBody;
  } else if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const res = await fetch(BASE + url, options);
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch { /* not JSON */ }
  return { status: res.status, json, text };
}

async function run(name, method, url, body, check, rawBody) {
  const sent = rawBody !== undefined ? rawBody : body === undefined ? "" : JSON.stringify(body);
  let actual = "";
  let pass = false;
  try {
    const r = await call(method, url, body, rawBody);
    actual = `${r.status} ${r.text.length > 160 ? r.text.slice(0, 160) + "..." : r.text}`;
    pass = !!check(r);
  } catch (error) {
    actual = `ERROR: ${error.message}`;
  }
  results.push({ name, method, url, sent, actual: actual.replace(/\s+/g, " "), pass });
  console.log(`${pass ? "PASS" : "FAIL"}  ${name}  ->  ${actual.replace(/\s+/g, " ").slice(0, 110)}`);
}

(async () => {
  console.log(`Testing ${BASE}\n`);
  try { await fetch(BASE + "/health"); } catch {
    console.error(`Cannot reach ${BASE}. Start the server first (START.bat or npm start).`);
    process.exit(1);
  }

  await run("1. GET /health", "GET", "/health", undefined, (r) => r.status === 200 && r.json && r.json.database === "connected");
  await run("2. GET all records", "GET", "/api/records", undefined, (r) => r.status === 200 && Array.isArray(r.json));
  await run("3. POST valid record", "POST", "/api/records", valid, (r) => {
    if (r.status === 201 && r.json && Number.isInteger(r.json.id)) { createdId = r.json.id; }
    return r.status === 201 && r.json.title === valid.title && r.json.status === "Pending" && createdId > 0;
  });
  await run("3b. POST ignores client-supplied id", "POST", "/api/records", { ...valid, id: 99999 }, (r) => {
    const ok = r.status === 201 && r.json.id !== 99999;
    if (r.json && r.json.id) call("DELETE", `/api/records/${r.json.id}`).catch(() => {});
    return ok;
  });
  await run("4. GET one record", "GET", `/api/records/${createdId}`, undefined, (r) => r.status === 200 && r.json.id === createdId && r.json.title === valid.title);
  await run("5. PUT same id", "PUT", `/api/records/${createdId}`, { title: "Light repaired", category: "Facilities", description: "Electrician replaced the faulty bulb.", status: "Completed" },
    (r) => r.status === 200 && r.json.id === createdId && r.json.title === "Light repaired" && r.json.status === "Completed");
  await run("6. DELETE same id", "DELETE", `/api/records/${createdId}`, undefined, (r) => r.status === 200 && r.json.message === "Record deleted.");
  await run("6b. GET deleted id gives 404", "GET", `/api/records/${createdId}`, undefined, (r) => r.status === 404 && !!r.json.message);

  await run("7. POST missing title", "POST", "/api/records", { category: "Electrical", description: "The light does not work.", status: "Pending" }, (r) => r.status === 400 && !!r.json.message);
  await run("8. POST invalid status", "POST", "/api/records", { ...valid, status: "Done" }, (r) => r.status === 400 && !!r.json.message);
  await run("9. POST wrong data types", "POST", "/api/records", { title: 123, category: ["x"], description: true, status: null }, (r) => r.status === 400 && !!r.json.message);
  await run("10. Invalid id (abc)", "GET", "/api/records/abc", undefined, (r) => r.status === 400 && !!r.json.message);
  await run("10b. Invalid id (0)", "DELETE", "/api/records/0", undefined, (r) => r.status === 400 && !!r.json.message);
  await run("11. GET nonexistent id", "GET", "/api/records/2000000000", undefined, (r) => r.status === 404 && !!r.json.message);
  await run("12. PUT nonexistent id", "PUT", "/api/records/2000000000", valid, (r) => r.status === 404 && !!r.json.message);
  await run("13. DELETE nonexistent id", "DELETE", "/api/records/2000000000", undefined, (r) => r.status === 404 && !!r.json.message);
  await run("14. Malformed JSON", "POST", "/api/records", undefined, (r) => r.status === 400 && !!r.json.message, '{"title": "Broken light", ');
  await run("15. Unknown route", "GET", "/api/unknown", undefined, (r) => r.status === 404 && !!r.json.message);
  await run("15b. GET / returns the HTML guide", "GET", "/", undefined, (r) => r.status === 200 && r.text.includes("<html"));
  await run("2b. Final check: list is still a JSON array", "GET", "/api/records", undefined, (r) => r.status === 200 && Array.isArray(r.json));

  const passed = results.filter((r) => r.pass).length;
  console.log(`\n${passed} of ${results.length} tests passed.`);
  console.log("Tests 16 (database failure) and 17 (restart persistence) are manual - see README.md.");

  const esc = (s) => String(s).replace(/\|/g, "\\|");
  const lines = [
    "# Automated API test results", "",
    `Target: ${BASE}`, `Run at: ${new Date().toISOString()}`, `Result: ${passed} of ${results.length} passed`, "",
    "| Test | Method | URL | Request body | Actual response | Result |", "|---|---|---|---|---|---|",
    ...results.map((r) => `| ${esc(r.name)} | ${r.method} | ${esc(r.url)} | ${esc(r.sent || "-")} | ${esc(r.actual)} | ${r.pass ? "PASS" : "FAIL"} |`), "",
    "Tests 16 (database connection failure) and 17 (persistence after restart) are manual; record them in docs/TESTING.md.", ""
  ];
  fs.writeFileSync(path.join(__dirname, "..", "docs", "TEST_RESULTS.md"), lines.join("\n"));
  console.log("Saved docs/TEST_RESULTS.md");
  process.exitCode = passed === results.length ? 0 : 1;
})();
